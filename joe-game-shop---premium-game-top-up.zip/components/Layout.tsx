
import React from 'react';
import { View, User } from '../types';
import { TELEGRAM_CHANNEL_URL } from '../constants';

interface LayoutProps {
  children: React.ReactNode;
  currentView: View;
  onNavigate: (view: View) => void;
  user?: User;
  onSearch?: (query: string) => void;
  searchQuery?: string;
  walletConnected?: boolean;
  onConnectWallet?: () => void;
  onOpenLogin?: () => void;
}

export const Sidebar: React.FC<Pick<LayoutProps, 'currentView' | 'onNavigate' | 'user' | 'onOpenLogin'>> = ({ currentView, onNavigate, user, onOpenLogin }) => {
  const menuItems = [
    { icon: 'home', label: 'Home', view: 'home' as View },
    { icon: 'diamond', label: 'MLBB Diamonds', view: 'mlbb-diamonds' as View },
    { icon: 'sports_esports', label: 'PUBG UC', view: 'pubg-uc' as View },
    { icon: 'history', label: 'History', view: 'history' as View },
    { icon: 'support_agent', label: 'Support', view: 'support' as View },
  ];

  return (
    <aside className="fixed left-0 top-0 h-screen w-64 border-r border-[#2f2348] bg-background-dark p-6 z-50 flex flex-col hidden md:flex">
      <div className="flex items-center gap-3 mb-10 cursor-pointer" onClick={() => onNavigate('home')}>
        <div className="bg-primary/20 p-2 rounded-lg text-primary">
          <span className="material-symbols-outlined text-3xl">smart_toy</span>
        </div>
        <div className="flex flex-col">
          <h1 className="text-white text-lg font-bold leading-none uppercase tracking-tight">JOE GAME SHOP</h1>
          <p className="text-[#a492c9] text-xs font-medium">Premium Gaming</p>
        </div>
      </div>
      <nav className="flex flex-col gap-2 mb-6">
        {menuItems.map((item) => (
          <button
            key={item.view}
            onClick={() => onNavigate(item.view)}
            className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
              currentView === item.view 
                ? 'bg-primary text-white shadow-lg shadow-primary/20' 
                : 'text-[#a492c9] hover:bg-white/5'
            }`}
          >
            <span className="material-symbols-outlined">{item.icon}</span>
            <span className="text-sm font-semibold tracking-wide">{item.label}</span>
          </button>
        ))}
      </nav>

      <a 
        href={TELEGRAM_CHANNEL_URL} 
        target="_blank" 
        rel="noopener noreferrer"
        className="mt-2 mb-6 bg-gradient-to-br from-[#0088cc] to-[#00aaff] p-4 rounded-xl flex flex-col gap-2 group transition-all hover:scale-[1.02] shadow-lg shadow-[#0088cc]/20"
      >
        <div className="flex items-center justify-between">
           <span className="material-symbols-outlined text-white text-2xl">send</span>
           <span className="bg-white/20 text-white text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">Join</span>
        </div>
        <div>
           <p className="text-white font-black text-sm">Telegram Channel</p>
           <p className="text-white/80 text-[10px] font-medium">Daily Deals & Updates</p>
        </div>
      </a>

      <div className="mt-auto pt-6 border-t border-[#2f2348]">
        {user?.isConnected ? (
          <div className="flex items-center gap-3 p-2 bg-[#2f2348]/40 rounded-xl border border-[#0088cc]/20">
            <div 
              className="size-10 rounded-full bg-cover bg-center border-2 border-[#0088cc]" 
              style={{ backgroundImage: `url(${user.avatar})` }}
            ></div>
            <div className="overflow-hidden">
              <div className="flex items-center gap-1">
                <p className="text-sm font-bold text-white truncate">{user.name}</p>
                <span className="material-symbols-outlined text-[#0088cc] text-xs font-black">verified</span>
              </div>
              <p className="text-[10px] text-[#a492c9] font-medium truncate">@{user.telegramUsername}</p>
            </div>
          </div>
        ) : (
          <button 
            onClick={onOpenLogin}
            className="w-full flex items-center justify-center gap-2 bg-[#0088cc]/10 hover:bg-[#0088cc]/20 text-[#0088cc] border border-[#0088cc]/30 py-3 rounded-xl transition-all group"
          >
            <span className="material-symbols-outlined text-xl transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5">send</span>
            <span className="text-xs font-black uppercase tracking-widest">Register Telegram</span>
          </button>
        )}
      </div>
    </aside>
  );
};

export const Header: React.FC<Pick<LayoutProps, 'onNavigate' | 'onSearch' | 'searchQuery' | 'walletConnected' | 'onConnectWallet' | 'user' | 'onOpenLogin'>> = ({ 
  onNavigate, 
  onSearch, 
  searchQuery,
  walletConnected,
  onConnectWallet,
  user,
  onOpenLogin
}) => {
  return (
    <header className="flex items-center justify-between px-4 md:px-10 py-4 sticky top-0 bg-background-dark/80 backdrop-blur-md z-40 border-b border-[#2f2348]">
      <div className="flex items-center gap-3">
        <div className="md:hidden bg-primary/20 p-1.5 rounded-lg cursor-pointer" onClick={() => onNavigate('home')}>
            <span className="material-symbols-outlined text-primary text-xl">smart_toy</span>
        </div>
        <h2 className="text-white text-lg md:text-xl font-bold tracking-tight">
          <span className="md:inline hidden">Dashboard</span>
          <span className="md:hidden inline text-sm uppercase tracking-widest">Joe Game Shop</span>
        </h2>
      </div>
      <div className="flex items-center gap-2 md:gap-6 flex-1 justify-end">
        <div className="relative max-w-64 hidden sm:block w-full">
          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-[#a492c9] text-xl">search</span>
          <input 
            className="w-full bg-[#2f2348] border-none rounded-lg pl-10 pr-4 py-2 text-white placeholder:text-[#a492c9] focus:ring-2 focus:ring-primary outline-none text-sm transition-all" 
            placeholder="Search games..." 
            type="text"
            value={searchQuery}
            onChange={(e) => onSearch?.(e.target.value)}
          />
        </div>
        
        {!user?.isConnected && (
           <button 
             onClick={onOpenLogin}
             className="hidden sm:flex items-center gap-2 bg-[#0088cc]/10 text-[#0088cc] px-4 py-2 rounded-lg border border-[#0088cc]/30 text-xs font-black uppercase tracking-wider hover:bg-[#0088cc]/20 transition-all"
           >
             <span className="material-symbols-outlined text-sm">send</span>
             Connect
           </button>
        )}

        <button 
          onClick={onConnectWallet}
          className={`${walletConnected ? 'bg-green-600' : 'bg-primary'} hover:opacity-90 text-white px-3 md:px-6 py-2 rounded-lg text-xs md:text-sm font-bold transition-all flex items-center gap-2`}
        >
          <span className="material-symbols-outlined text-base md:text-lg">{walletConnected ? 'account_balance' : 'account_balance_wallet'}</span>
          <span className="hidden xs:inline">{walletConnected ? '500,000 MMK' : 'Connect'}</span>
        </button>
      </div>
    </header>
  );
};

export const BottomNav: React.FC<Pick<LayoutProps, 'currentView' | 'onNavigate'>> = ({ currentView, onNavigate }) => {
  const navItems = [
    { icon: 'home', label: 'Home', view: 'home' as View },
    { icon: 'diamond', label: 'MLBB', view: 'mlbb-diamonds' as View },
    { icon: 'sports_esports', label: 'PUBG', view: 'pubg-uc' as View },
    { icon: 'history', label: 'History', view: 'history' as View },
    { icon: 'support_agent', label: 'Support', view: 'support' as View },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background-dark/95 backdrop-blur-lg border-t border-[#2f2348] flex justify-around items-center py-2 px-1 z-50 md:hidden pb-safe">
      {navItems.map((item) => (
        <button
          key={item.view}
          onClick={() => onNavigate(item.view)}
          className={`flex flex-col items-center gap-0.5 min-w-[64px] transition-all ${
            currentView === item.view ? 'text-primary' : 'text-[#a492c9]'
          }`}
        >
          <span className={`material-symbols-outlined text-2xl ${currentView === item.view ? 'fill-1' : ''}`}>
            {item.icon}
          </span>
          <span className="text-[10px] font-bold uppercase tracking-tighter">{item.label}</span>
          {currentView === item.view && <div className="w-1 h-1 bg-primary rounded-full mt-0.5"></div>}
        </button>
      ))}
    </nav>
  );
};

export const Layout: React.FC<LayoutProps> = (props) => {
  const { children, currentView, onNavigate, user, onOpenLogin } = props;
  return (
    <div className="flex min-h-screen bg-background-dark overflow-x-hidden">
      <Sidebar currentView={currentView} onNavigate={onNavigate} user={user} onOpenLogin={onOpenLogin} />
      <div className="flex-1 md:ml-64 flex flex-col min-w-0">
        <Header {...props} />
        <main className="p-4 md:p-10 flex-1 pb-24 md:pb-10">
          {children}
        </main>
      </div>
      <BottomNav currentView={currentView} onNavigate={onNavigate} />
    </div>
  );
};
