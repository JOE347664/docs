
import { GoogleGenAI } from "@google/genai";

// Always use the process.env.API_KEY directly as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getSupportResponse(userMessage: string) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: userMessage,
      config: {
        systemInstruction: "You are JOE GAME SHOP support, a helpful assistant for a gaming currency top-up shop. Users come here to buy Diamonds for Mobile Legends and UC for PUBG. If they ask about delivery, tell them it's instant through our secure bots. If they ask about issues, tell them to provide their Order ID starting with #TX. Keep responses concise and friendly.",
      },
    });
    // Use .text property directly as it is a property, not a method
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm having trouble connecting to my knowledge base. Please try again or contact us via Telegram.";
  }
}
