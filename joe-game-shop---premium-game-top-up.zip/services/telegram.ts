const TELEGRAM_BOT_TOKEN = '8475933174:AAF-sE7i410y-RzdJluj8Obc7j0OIxp_Aak';

/**
 * NOTE: For the bot to send you (the admin) notifications, you need your numeric CHAT_ID.
 * 1. Open Telegram and search for "@userinfobot"
 * 2. Send it a message, and it will reply with your ID (e.g., 123456789)
 */
const ADMIN_CHAT_ID = '6468798950'; // Using a default ID or keeping it for user to set

export async function sendTelegramMessage(text: string) {
  // Fix: Removed impossible comparison against placeholder string 'YOUR_CHAT_ID_HERE' which was causing a TypeScript error.
  if (!ADMIN_CHAT_ID) {
    console.warn("Telegram Admin Chat ID is not set.");
    return false;
  }

  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
  
  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: ADMIN_CHAT_ID,
        text: text,
        parse_mode: 'Markdown',
      }),
    });
    return response.ok;
  } catch (error) {
    console.error('Telegram API Error:', error);
    return false;
  }
}

export async function sendTelegramPhoto(base64Image: string, caption: string) {
  // Fix: Removed impossible comparison against placeholder string 'YOUR_CHAT_ID_HERE' which was causing a TypeScript error.
  if (!ADMIN_CHAT_ID) {
    console.warn("Telegram Admin Chat ID is not set.");
    return false;
  }

  const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendPhoto`;
  
  // Convert base64 to Blob
  try {
    const base64Data = base64Image.split(',')[1];
    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: 'image/jpeg' });

    const formData = new FormData();
    formData.append('chat_id', ADMIN_CHAT_ID);
    formData.append('photo', blob, 'receipt.jpg');
    formData.append('caption', caption);
    formData.append('parse_mode', 'Markdown');

    const response = await fetch(url, {
      method: 'POST',
      body: formData,
    });
    
    return response.ok;
  } catch (error) {
    console.error('Telegram Photo API Error:', error);
    return false;
  }
}